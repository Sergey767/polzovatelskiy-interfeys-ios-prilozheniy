//
//  SomeImagesNewsCell.swift
//  Vkontakte
//
//  Created by Серёжа on 03/10/2019.
//  Copyright © 2019 appleS. All rights reserved.
//

import UIKit

/*class SomeImagesNewsCell: UICollectionViewCell {
    
    static let reuseIdentifier = "SomeImagesNewsCell"
    
    @IBOutlet weak var someImages: UIImageView!
    
}*/
