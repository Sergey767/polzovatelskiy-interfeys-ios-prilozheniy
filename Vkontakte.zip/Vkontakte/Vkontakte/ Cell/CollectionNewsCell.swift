//
//  CollectionNewsCell.swift
//  Vkontakte
//
//  Created by Серёжа on 02/10/2019.
//  Copyright © 2019 appleS. All rights reserved.
//

import UIKit

/*class CollectionNewsCell: UITableViewCell {
    
    static let reuseIdentifier = "CollectionNewsCell"
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    
    var bartImages = ["bartS", "bartSim"]
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        collectionView.dataSource = self
        collectionView.delegate = self
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
}

extension CollectionNewsCell: UICollectionViewDataSource, UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return bartImages.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
         
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "SomeImagesNewsCell", for: indexPath) as! SomeImagesNewsCell
        
        cell.someImages.image = UIImage(named: bartImages[indexPath.row])
        
        return cell
    }

}*/
