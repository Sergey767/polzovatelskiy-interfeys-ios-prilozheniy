//
//  GroupModel.swift
//  Vkontakte
//
//  Created by Серёжа on 12/07/2019.
//  Copyright © 2019 appleS. All rights reserved.
//

import Foundation

struct Group {
    
    var nameGroup: String
    var subscribers: Int
    var siteGroup: String
    var dateOfCreation: String
    var numberOfRecords: Int
    var photo: String
}


